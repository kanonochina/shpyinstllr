$( document ).ready( function() {
	if(new Date()>new Date($.cookie("time")))
	{
		$.removeCookie("time", { path: "/" });
	}
	timeOff	= function(event)
	{
		if( $(".shop-btn").length > 0 )
		{
			window.location.href = $(".shop-btn").attr("redirect");
		}
		if( $(".previewbar").size() > 0 )
		{
			window.location.href = $(".previewbar").attr("link");
		}
	}
	fun_countdown	= function()
	{
		cookie_time	= new Date($.cookie("time"));
		$('.time_left').countdown({until: cookie_time, format: "MS", onExpiry: timeOff, padZeroes: true});
		$('#defaultCountdown').countdown({until: cookie_time, format: "MS", onExpiry: timeOff, padZeroes: true});
		$('#defaultCountdown').show();
		previewbar	= $(".previewbar");
		if(previewbar.length > 0)
		{
			previewbar.show();
			pos	= previewbar.position().top;
			out	= previewbar.outerHeight();
			if(pos < 100)
			{
				$("body").css({ marginTop: out+'px' });
			} else {
				$("body").css({ marginBottom: out+'px' });
			}
		}
		window_resize() ;
	}
	window_resize	= function()
	{
		if( $( ".coupon-for-another" ).width() < 560 )
		{
			$( ".coupon_responsive" ).hide() ;
			$( ".coupon_image" ).show() ;
		} else {
			$( ".coupon_image" ).hide() ;
			$( ".coupon_responsive" ).show() ;
		}
	}
	window_load	= function( time )
	{
		if(!$.cookie("time") || $.cookie("time") == "null")
		{
			newDate = new Date();
			newDate.setMinutes(newDate.getMinutes() + time);
			$.cookie("time", newDate, { path: "/" });
		}
		newYear = new Date($.cookie("time"));
		href_url	= $(".href_url").attr("href");
		product	= "" ;
		if( products )
		{
			product	= "&products=" + products.join(",") ;
		}
		$( ".href_url" ).attr( "href" , href_url + "?db=" + Number( newYear ) + product );
		$(".coupon-for-another").show();
		fun_countdown();
	}
	currentHref = window.location.href;
	ct = currentHref.split('?db=');
	if (ct.length > 1)
	{
		newYear = new Date(parseInt(ct[1],10));
		if(new Date() < newYear)
		{
			$.cookie("time", newYear, { path: "/" });
		}
	}
	if($.cookie("time") && $.cookie("time") != "null")
	{
		get_url = getUrlVars() ;
		if( get_url.db )
		{
			$.removeCookie("previewbar", { path: "/" });
		}
		if($.cookie("previewbar") && $.cookie("previewbar") != "null")
		{
			$( "body" ).append( $.cookie("previewbar") ) ;
			fun_countdown();
		} else {
			try {
				fun_previewbar() ;
			} catch(err) {
			}
		}
		$(".previewbar").click(function(){
			window.location.href = $(".previewbar").attr("href");
		});
	}
} ) ;
getUrlVars	= function ()
{
	vars = {} ;
	url	= window.location.href ;
	if( url.indexOf('?') >= 0 )
	{
		hashes = url.slice(url.indexOf('?') + 1).split('&');
		for( i = 0 ; i < hashes.length ; i++ )
		{
			hash = hashes[i].split('=');
			vars[hash[0]] = hash[1];
		}
	}
	return vars;
}
$( window ).resize(function() {
	window_resize() ;
});